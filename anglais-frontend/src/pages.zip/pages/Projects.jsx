import { useState, useEffect } from 'react';

export default function Projects() {
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('all'); // 'all', 'collaborative', 'missions'

  // État pour la modale de création de projet
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [projectType, setProjectType] = useState('collaborative'); // 'collaborative' ou 'mission'
  const [requiredLevel, setRequiredLevel] = useState('B2');
  const [tagsInput, setTagsInput] = useState('#React, #CSS');
  const [error, setError] = useState('');

  // Charger les projets (simulation ou API)
  useEffect(() => {
    // Projets initiaux par défaut
    const initialProjects = [
      {
        id: 1,
        title: "Création d'un site E-Commerce pour un Club d'Échecs",
        description: "Recherche développeur un React et un rédacteur pour créer le contenu en anglais.",
        type: "collaborative",
        categoryText: "PROJET COLLABORATIF",
        timeAgo: "Il y a 2h",
        tags: ["#Réagir", "#Copywriting", "#CSS"],
        requiredLevel: "B2",
        author: "Admin"
      },
      {
        id: 2,
        title: "Traduction technique de documentation API (FR -> EN)",
        description: "Mission court terme pour une documentation technique de Python vers l'anglais.",
        type: "mission",
        categoryText: "MISSION / ÉTAPE",
        timeAgo: "Hier",
        tags: ["#Python", "#Traduction", "#FastAPI"],
        requiredLevel: "C1",
        author: "Admin"
      }
    ];
    setProjects(initialProjects);
    setLoading(false);
  }, []);

  // Gestion de la soumission du nouveau projet
  const handleCreateProject = (e) => {
    e.preventDefault();
    setError('');

    if (!title.trim() || !description.trim()) {
      setError("Veuillez remplir tous les champs obligatoires.");
      return;
    }

    // Transformer les tags saisis en tableau
    const tagsArray = tagsInput.split(',').map(tag => tag.trim().startsWith('#') ? tag.trim() : `#${tag.trim()}`);

    const newProject = {
      id: Date.now(),
      title: title.trim(),
      description: description.trim(),
      type: projectType,
      categoryText: projectType === 'collaborative' ? 'PROJET COLLABORATIF' : 'MISSION / ÉTAPE',
      timeAgo: "À l'instant",
      tags: tagsArray,
      requiredLevel: requiredLevel,
      author: "Moi"
    };

    setProjects([newProject, ...projects]);
    
    // Réinitialiser et fermer la modale
    setTitle('');
    setDescription('');
    setTagsInput('#React, #CSS');
    setIsModalOpen(false);
  };

  // Filtrage des projets selon l'onglet actif
  const filteredProjects = projects.filter(p => {
    if (activeTab === 'collaborative') return p.type === 'collaborative';
    if (activeTab === 'missions') return p.type === 'mission';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* En-tête du module + bouton de création */}
      <div className="bg-white p-5 rounded-lg shadow-sm border border-slate-200 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Conseil des Projets & Missions 🎯</h2>
          <p className="text-sm text-slate-500">Collaborez sur des projets et pratiquez l'anglais au quotidien.</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-red-600 hover:bg-red-700 text-white font-bold text-sm px-4 py-2 rounded transition shadow-sm cursor-pointer"
        >
          + Publier un projet
        </button>
      </div>

      {/* Onglets de filtrage */}
      <div className="flex gap-2 border-b border-slate-200 pb-3">
        <button 
          onClick={() => setActiveTab('all')}
          className={`px-4 py-2 rounded-full text-xs font-bold transition ${activeTab === 'all' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Tous les projets
        </button>
        <button 
          onClick={() => setActiveTab('collaborative')}
          className={`px-4 py-2 rounded-full text-xs font-bold transition ${activeTab === 'collaborative' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Projets Collaboratifs
        </button>
        <button 
          onClick={() => setActiveTab('missions')}
          className={`px-4 py-2 rounded-full text-xs font-bold transition ${activeTab === 'missions' ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
        >
          Missions et étapes
        </button>
      </div>

      {/* Liste des projets */}
      <div className="space-y-4">
        {loading ? (
          <p className="text-center text-slate-500 py-6">Chargement des projets...</p>
        ) : filteredProjects.length === 0 ? (
          <p className="text-center text-slate-500 py-6 bg-white p-6 rounded-lg border border-slate-200">
            Aucun projet trouvé dans cette catégorie.
          </p>
        ) : (
          filteredProjects.map(project => (
            <div key={project.id} className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 relative">
              <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-red-600 bg-red-50 px-2.5 py-1 rounded border border-red-100">
                  {project.categoryText}
                </span>
                <span className="text-xs text-slate-400">{project.timeAgo}</span>
              </div>

              <h3 className="text-lg font-black text-slate-900 mb-1">{project.title}</h3>
              <p className="text-slate-600 text-sm mb-4">{project.description}</p>

              <div className="flex flex-wrap items-center justify-between gap-4 pt-3 border-t border-slate-100">
                <div className="flex gap-2 flex-wrap">
                  {project.tags.map((tag, idx) => (
                    <span key={idx} className="text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded font-medium">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-semibold text-slate-500">
                    Niveau requis : <strong className="text-slate-800">{project.requiredLevel}</strong>
                  </span>
                  <button 
                    onClick={() => alert(`Candidature envoyée pour le projet : ${project.title}`)}
                    className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2 rounded transition cursor-pointer"
                  >
                    Postuler / Répondre
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* MODALE DE CRÉATION DE PROJET */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex justify-center items-center z-50 p-4">
          <div className="bg-white w-full max-w-lg rounded-xl shadow-xl border border-slate-200 overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="flex justify-between items-center bg-slate-900 text-white px-6 py-4">
              <h3 className="font-bold text-base">Publier un nouveau projet ou mission</h3>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white font-bold text-lg cursor-pointer"
              >
                &times;
              </button>
            </div>

            <form onSubmit={handleCreateProject} className="p-6 space-y-4">
              {error && <div className="p-3 bg-red-50 border border-red-200 text-red-600 text-xs rounded">{error}</div>}

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Titre du projet</label>
                <input 
                  type="text" 
                  placeholder="Ex: Application mobile d'apprentissage..." 
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Description et objectifs</label>
                <textarea 
                  placeholder="Décrivez ce que vous recherchez..." 
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded text-sm h-24 focus:outline-none focus:ring-2 focus:ring-red-500 resize-none"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Type</label>
                  <select 
                    value={projectType} 
                    onChange={(e) => setProjectType(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded text-sm bg-white focus:outline-none"
                  >
                    <option value="collaborative">Projet Collaboratif</option>
                    <option value="mission">Mission / Étape</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Niveau d'anglais requis</label>
                  <select 
                    value={requiredLevel} 
                    onChange={(e) => setRequiredLevel(e.target.value)}
                    className="w-full p-2.5 border border-slate-200 rounded text-sm bg-white focus:outline-none"
                  >
                    <option value="A1">A1 (Débutant)</option>
                    <option value="A2">A2 (Élémentaire)</option>
                    <option value="B1">B1 (Intermédiaire)</option>
                    <option value="B2">B2 (Avancé)</option>
                    <option value="C1">C1 (Autonome)</option>
                    <option value="C2">C2 (Maîtrise)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">Tags (séparés par des virgules)</label>
                <input 
                  type="text" 
                  placeholder="#React, #Design, #English" 
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  className="w-full p-2.5 border border-slate-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded transition cursor-pointer"
                >
                  Annuler
                </button>
                <button 
                  type="submit"
                  className="bg-red-600 hover:bg-red-700 text-white text-xs font-bold px-5 py-2 rounded transition cursor-pointer"
                >
                  Publier le projet
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}