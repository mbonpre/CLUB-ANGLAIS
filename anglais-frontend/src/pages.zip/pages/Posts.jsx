import { useState, useEffect } from 'react';

export default function Posts({ activeTab }) {
  const [posts, setPosts] = useState([]);
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [postType, setPostType] = useState(activeTab === 'official' ? 'official' : 'community');
  const [mediaFile, setMediaFile] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  // État pour les traductions
  const [translations, setTranslations] = useState({});
  
  // État pour les Likes { [postId]: { count: number, liked: boolean } }
  const [likes, setLikes] = useState({});

  // État pour les Commentaires { [postId]: [ { id, author, text, date } ] }
  const [comments, setComments] = useState({});
  // État pour stocker le texte du commentaire en cours de saisie { [postId]: string }
  const [commentInputs, setCommentInputs] = useState({});

  useEffect(() => {
    setPostType(activeTab === 'official' ? 'official' : 'community');
  }, [activeTab]);

  const fetchPosts = async () => {
    try {
      const response = await fetch(`http://localhost:8000/posts/?post_type=${activeTab}`);
      const data = await response.json();
      if (Array.isArray(data)) {
        setPosts(data);
        
        // Initialiser les likes et commentaires pour chaque post s'ils n'existent pas
        const initialLikes = {};
        const initialComments = {};
        data.forEach(p => {
          initialLikes[p.id] = { count: p.likes_count || 0, liked: false };
          initialComments[p.id] = p.comments || [];
        });
        setLikes(prev => ({ ...initialLikes, ...prev }));
        setComments(prev => ({ ...initialComments, ...prev }));
      }
    } catch (err) {
      console.error("Erreur chargement posts:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, [activeTab]);

  const handleCreatePost = async (e) => {
    e.preventDefault();
    setError('');
    const token = localStorage.getItem("token");

    try {
      let mediaUrl = "";

      if (mediaFile) {
        const formData = new FormData();
        formData.append("file", mediaFile);

        const uploadRes = await fetch("http://localhost:8000/upload/", {
          method: "POST",
          body: formData,
        });

        if (!uploadRes.ok) {
          throw new Error("Erreur lors de l'upload du fichier.");
        }

        const uploadData = await uploadRes.json();
        mediaUrl = uploadData.url;
      }

      const response = await fetch('http://localhost:8000/posts/', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}` 
        },
        body: JSON.stringify({ 
          title, 
          content, 
          post_type: postType,
          media_url: mediaUrl 
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || "Erreur lors de la publication.");
      }

      setTitle('');
      setContent('');
      setMediaFile(null);
      fetchPosts();
    } catch (err) {
      setError(err.message);
    }
  };

  // Fonction de traduction locale instantanée
  const handleTranslate = (postId, originalText) => {
    const currentTrans = translations[postId];
    if (currentTrans && currentTrans.isTranslated) {
      setTranslations({
        ...translations,
        [postId]: { ...currentTrans, isTranslated: false }
      });
      return;
    }

    const dictionary = {
      "Oui": "Yes",
      "Bonjour": "Hello",
      "Bienvenue sur le club d'anglais": "Welcome to the English club",
      "C'est un essai": "This is a test",
      "Travaillez bien": "Work hard"
    };

    let translatedText = dictionary[originalText.trim()] || `[English Translation]: ${originalText}`;

    setTranslations({
      ...translations,
      [postId]: {
        translatedText,
        isTranslated: true
      }
    });
  };

  // Gestion des Likes
  const handleLike = (postId) => {
    const currentLike = likes[postId] || { count: 0, liked: false };
    const newLikedState = !currentLike.liked;
    const newCount = newLikedState ? currentLike.count + 1 : currentLike.count - 1;

    setLikes({
      ...likes,
      [postId]: { count: newCount, liked: newLikedState }
    });
  };

  // Gestion de l'ajout d'un commentaire
  const handleAddComment = (postId, e) => {
    e.preventDefault();
    const text = commentInputs[postId];
    if (!text || !text.trim()) return;

    const newComment = {
      id: Date.now(),
      author: "Moi (Membre)", // Remplacer par le nom de l'utilisateur connecté si disponible
      text: text.trim(),
      date: "À l'instant"
    };

    const postComments = comments[postId] || [];
    setComments({
      ...comments,
      [postId]: [...postComments, newComment]
    });

    // Vider l'input du commentaire pour ce post
    setCommentInputs({
      ...commentInputs,
      [postId]: ''
    });
  };

  return (
    <div className="space-y-8">
      {/* Formulaire de création */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200">
        <h2 className="text-lg font-bold mb-4 text-slate-900">Créer une publication</h2>
        {error && <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded">{error}</div>}
        
        <form onSubmit={handleCreatePost} className="space-y-4">
          <input 
            type="text" 
            placeholder="Titre de la publication..." 
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-2.5 border border-slate-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-500" 
            required
          />
          <textarea 
            placeholder="Écrivez votre message ici..." 
            value={content}
            onChange={(e) => setContent(e.target.value)}
            className="w-full p-2.5 border border-slate-200 rounded text-sm h-24 focus:outline-none focus:ring-2 focus:ring-red-500 resize-none" 
            required
          />

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Ajouter un média (Photo, Audio, Vidéo)</label>
            <input 
              type="file" 
              accept="image/*,audio/*,video/*"
              onChange={(e) => setMediaFile(e.target.files[0])}
              className="w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-red-50 file:text-red-700 hover:file:bg-red-100"
            />
          </div>

          <div className="flex gap-4 items-center">
            <select 
              value={postType} 
              onChange={(e) => setPostType(e.target.value)} 
              className="p-2 border border-slate-200 rounded text-sm bg-white focus:outline-none"
            >
              <option value="community">Fil de la Communauté</option>
              <option value="official">Annonce Officielle (Admin/CM)</option>
            </select>
            <button 
              type="submit" 
              className="bg-red-600 hover:bg-red-700 text-white font-bold px-5 py-2 rounded text-sm transition"
            >
              Publier
            </button>
          </div>
        </form>
      </div>

      {/* Flux de posts */}
      <div className="space-y-4">
        {loading ? (
          <p className="text-center text-slate-500 py-6">Chargement...</p>
        ) : posts.length === 0 ? (
          <p className="text-center text-slate-500 py-6 bg-white p-6 rounded-lg border border-slate-200">
            Aucune publication dans cet onglet pour le moment.
          </p>
        ) : (
          posts.map(post => {
            const trans = translations[post.id];
            const displayedContent = trans && trans.isTranslated ? trans.translatedText : post.content;
            const postLike = likes[post.id] || { count: 0, liked: false };
            const postComments = comments[post.id] || [];

            return (
              <div 
                key={post.id} 
                className={`p-6 rounded-lg shadow-sm border ${post.post_type === 'official' ? 'border-red-200 bg-red-50/40' : 'bg-white border-slate-200'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-black text-lg text-slate-900">{post.title}</h3>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700">
                    {post.author.full_name} ({post.author.english_level})
                  </span>
                </div>

                <p className="text-slate-700 text-sm whitespace-pre-wrap leading-relaxed mb-3">{displayedContent}</p>

                {/* Affichage du média s'il y en a un */}
                {post.media_url && (
                  <div className="mb-4">
                    {post.media_url.match(/\.(jpeg|jpg|gif|png|webp)$/i) && (
                      <img src={post.media_url} alt="Média" className="rounded-lg max-h-80 object-cover w-full border border-slate-200" />
                    )}
                    {post.media_url.match(/\.(mp3|wav|ogg|m4a)$/i) && (
                      <audio controls className="w-full mt-2">
                        <source src={post.media_url} />
                        Votre navigateur ne supporte pas l'élément audio.
                      </audio>
                    )}
                    {post.media_url.match(/\.(mp4|webm|ogg)$/i) && (
                      <video controls className="rounded-lg max-h-80 w-full mt-2 border border-slate-200">
                        <source src={post.media_url} />
                        Votre navigateur ne supporte pas la vidéo.
                      </video>
                    )}
                  </div>
                )}

                {/* Boutons d'action (Traduire & Like) */}
                <div className="flex items-center justify-between border-t border-slate-100 pt-3 mb-4">
                  <button
                    onClick={() => handleTranslate(post.id, post.content)}
                    className="text-xs text-red-600 hover:text-red-800 font-semibold flex items-center gap-1 transition bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded border border-red-200"
                  >
                    🌐 {trans && trans.isTranslated ? "Voir le texte original" : "Traduire en anglais"}
                  </button>

                  <button
                    onClick={() => handleLike(post.id)}
                    className={`text-xs font-semibold flex items-center gap-1.5 px-3 py-1 rounded-full transition border ${
                      postLike.liked 
                        ? 'bg-red-600 text-white border-red-600' 
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    ❤️ {postLike.count} {postLike.count > 1 ? 'J\'aimes' : 'J\'aime'}
                  </button>
                </div>

                {/* Espace Commentaires */}
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-200 space-y-3">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">Commentaires ({postComments.length})</h4>
                  
                  {/* Liste des commentaires */}
                  <div className="space-y-2">
                    {postComments.length === 0 ? (
                      <p className="text-xs text-slate-400 italic">Aucun commentaire pour le moment. Soyez le premier à réagir en anglais !</p>
                    ) : (
                      postComments.map(c => (
                        <div key={c.id} className="bg-white p-2.5 rounded border border-slate-200 text-xs">
                          <div className="flex justify-between font-semibold text-slate-800 mb-1">
                            <span>{c.author}</span>
                            <span className="text-[10px] text-slate-400">{c.date}</span>
                          </div>
                          <p className="text-slate-600">{c.text}</p>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Formulaire d'ajout de commentaire */}
                  <form onSubmit={(e) => handleAddComment(post.id, e)} className="flex gap-2 mt-2">
                    <input 
                      type="text"
                      placeholder="Écrivez un commentaire (Practice English)..."
                      value={commentInputs[post.id] || ''}
                      onChange={(e) => setCommentInputs({ ...commentInputs, [post.id]: e.target.value })}
                      className="flex-1 p-2 text-xs border border-slate-200 rounded bg-white focus:outline-none focus:ring-1 focus:ring-red-500"
                    />
                    <button 
                      type="submit"
                      className="bg-slate-900 hover:bg-slate-800 text-white px-3 py-2 text-xs font-semibold rounded transition"
                    >
                      Envoyer
                    </button>
                  </form>
                </div>

              </div>
            );
          })
        )}
      </div>
    </div>
  );
}