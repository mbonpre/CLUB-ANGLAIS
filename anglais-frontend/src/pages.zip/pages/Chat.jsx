import { useState } from 'react';

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const [traductions, setTraductions] = useState({});

  // Envoi du message saisi par l'utilisateur
  const envoyer = (e) => {
    e.preventDefault();
    if (!text.trim()) return;

    const nouveauMessage = {
      id: Date.now() + Math.random(), // évite les collisions d'id si deux messages arrivent à la même ms
      contenu: text.trim()
    };
    setMessages((prev) => [...prev, nouveauMessage]);
    setText("");
  };

  // Gestion du clic pour traduire ou voir l'original
  const basculerTraduction = (id, texteOriginal) => {
    setTraductions((prev) => {
      const estDejaTraduit = prev[id];

      if (estDejaTraduit) {
        const copie = { ...prev };
        delete copie[id];
        return copie;
      } else {
        const lower = texteOriginal.toLowerCase().trim();
        let resultatTraduit = `[Traduction] : ${texteOriginal}`;
        if (lower === "hello") {
          resultatTraduit = "bonjour";
        } else if (lower === "bonjour") {
          resultatTraduit = "hello";
        }
        return { ...prev, [id]: resultatTraduit };
      }
    });
  };

  return (
    <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 max-w-2xl mx-auto">
      <h2 className="text-lg font-bold mb-4 text-slate-900">Messagerie du Club</h2>

      <div className="border border-slate-200 rounded-lg min-h-[250px] max-h-[400px] overflow-y-auto p-4 mb-4 bg-slate-50 space-y-3">
        {messages.length === 0 ? (
          <p className="text-slate-400 text-center italic py-10">Aucun message pour le moment. Commencez la discussion !</p>
        ) : (
          messages.map(msg => {
            const texteAffiche = traductions[msg.id] !== undefined ? traductions[msg.id] : msg.contenu;
            const estTraduit = traductions[msg.id] !== undefined;
            return (
              <div key={msg.id} className="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                <p className="text-slate-800 text-sm mb-2">{texteAffiche}</p>
                <button
                  type="button"
                  onClick={() => basculerTraduction(msg.id, msg.contenu)}
                  className="text-xs text-red-600 hover:text-red-800 font-semibold bg-red-50 hover:bg-red-100 px-2.5 py-1 rounded border border-red-200 transition"
                >
                  🌐 {estTraduit ? "Voir l'original" : "Traduire"}
                </button>
              </div>
            );
          })
        )}
      </div>

      <form onSubmit={envoyer} className="flex gap-2">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Tapez 'hello' ou 'bonjour'..."
          className="flex-1 p-2.5 border border-slate-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-500 bg-white"
        />
        <button
          type="submit"
          className="bg-red-600 hover:bg-red-700 text-white font-bold px-5 py-2.5 rounded text-sm transition"
        >
          Envoyer
        </button>
      </form>
    </div>
  );
}