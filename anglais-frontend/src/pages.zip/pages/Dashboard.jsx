import { useState, useEffect } from 'react';
import Members from './Members.jsx';
import Projects from './Projects.jsx';
import Chat from './Chat.jsx';
import Posts from './Posts.jsx';

export default function Dashboard({ onLogout }) {
  const [currentPage, setCurrentPage] = useState('home'); // 'home', 'members', 'projects', 'chat'
  const [activeTab, setActiveTab] = useState('official');
  
  // État pour gérer la photo de profil (sauvegardée temporairement dans le navigateur)
  const [profilePic, setProfilePic] = useState(() => {
    return localStorage.getItem('user_profile_pic') || null;
  });

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result;
        setProfilePic(base64String);
        localStorage.setItem('user_profile_pic', base64String); // Enregistrement local
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 font-sans">
      {/* En-tête UK/British Style */}
      <header className="bg-slate-900 text-white border-b-4 border-red-600 sticky top-0 z-10 shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center space-x-6">
            <h1 className="text-xl font-black tracking-wide flex items-center gap-2 cursor-pointer" onClick={() => setCurrentPage('home')}>
              <span>English Club</span>
              <span className="text-xs bg-red-600 text-white font-bold px-1.5 py-0.5 rounded uppercase">UK</span>
            </h1>
            <nav className="hidden md:flex space-x-5 text-sm font-medium text-slate-300">
              <button
                onClick={() => setCurrentPage('home')}
                className={currentPage === 'home' ? 'text-white border-b-2 border-red-500 pb-0.5 font-semibold' : 'hover:text-white transition'}
              >
                Accueil
              </button>
              <button
                onClick={() => setCurrentPage('members')}
                className={currentPage === 'members' ? 'text-white border-b-2 border-red-500 pb-0.5 font-semibold' : 'hover:text-white transition'}
              >
                Membres & CV
              </button>
              <button
                onClick={() => setCurrentPage('projects')}
                className={currentPage === 'projects' ? 'text-white border-b-2 border-red-500 pb-0.5 font-semibold' : 'hover:text-white transition'}
              >
                Projets & Offres
              </button>
              <button
                onClick={() => setCurrentPage('chat')}
                className={currentPage === 'chat' ? 'text-white border-b-2 border-red-500 pb-0.5 font-semibold' : 'hover:text-white transition'}
              >
                Messagerie 💬
              </button>
            </nav>
          </div>
          <button
            onClick={onLogout}
            className="bg-red-600 hover:bg-red-700 text-white text-sm font-medium px-4 py-1.5 rounded transition shadow-sm"
          >
            Déconnexion
          </button>
        </div>
      </header>

      {/* Rendu dynamique des vues */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        {currentPage === 'members' && <Members />}
        {currentPage === 'projects' && <Projects />}
        {currentPage === 'chat' && <Chat />}
        {currentPage === 'home' && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Colonne de gauche : Profil Rapide style Facebook avec Avatar modifiable */}
            <div className="md:col-span-1 space-y-4">
              <div className="bg-white rounded-lg shadow-sm border border-slate-200 p-4 text-center">
                <div className="relative w-20 h-20 mx-auto mb-3 group">
                  <div className="w-20 h-20 bg-slate-200 rounded-full overflow-hidden flex items-center justify-center text-2xl font-bold text-slate-700 border-2 border-slate-300">
                    {profilePic ? (
                      <img src={profilePic} alt="Profil" className="w-full h-full object-cover" />
                    ) : (
                      <span>👑</span>
                    )}
                  </div>
                  {/* Label agissant comme bouton pour changer la photo au survol */}
                  <label htmlFor="profile-pic-input" className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center text-white text-xs opacity-0 group-hover:opacity-100 transition cursor-pointer">
                    Modifier
                  </label>
                  <input 
                    id="profile-pic-input" 
                    type="file" 
                    accept="image/*" 
                    className="hidden" 
                    onChange={handleImageChange} 
                  />
                </div>
                <h2 className="font-bold text-slate-900">Administrateur</h2>
                <p className="text-xs text-red-600 font-semibold uppercase mt-0.5">Super Admin</p>
                <div className="mt-4 pt-4 border-t border-slate-100 text-left text-sm space-y-2">
                  <button 
                    onClick={() => setCurrentPage('members')} 
                    className="w-full text-left px-2 py-1.5 rounded hover:bg-slate-50 text-slate-700 font-medium transition flex items-center gap-2"
                  >
                    👥 Annuaire des membres
                  </button>
                  <button 
                    onClick={() => setCurrentPage('projects')} 
                    className="w-full text-left px-2 py-1.5 rounded hover:bg-slate-50 text-slate-700 font-medium transition flex items-center gap-2"
                  >
                    🚀 Projets & Offres
                  </button>
                  <button 
                    onClick={() => setCurrentPage('chat')} 
                    className="w-full text-left px-2 py-1.5 rounded hover:bg-slate-50 text-slate-700 font-medium transition flex items-center gap-2"
                  >
                    💬 Messagerie
                  </button>
                </div>
              </div>
            </div>

            {/* Colonne centrale : Fil d'actualité et création de post */}
            <div className="md:col-span-3">
              {/* Système à Double Flux (Onglets) */}
              <div className="flex border border-slate-200 mb-6 bg-white rounded-lg p-1.5 shadow-sm">
                <button
                  onClick={() => setActiveTab('official')}
                  className={`flex-1 py-2.5 text-center font-bold text-sm rounded-md transition ${
                    activeTab === 'official' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  📢 À la Une du Club (Officiel)
                </button>
                <button
                  onClick={() => setActiveTab('community')}
                  className={`flex-1 py-2.5 text-center font-bold text-sm rounded-md transition ${
                    activeTab === 'community' ? 'bg-red-600 text-white shadow' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  👥 Fil de la Communauté
                </button>
              </div>

              {/* Affichage dynamique du composant Posts filtré selon l'onglet actif */}
              <Posts activeTab={activeTab} />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}