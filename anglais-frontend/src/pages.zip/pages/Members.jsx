import { useState, useEffect } from 'react';

export default function Members() {
  const [search, setSearch] = useState('');
  const [levelFilter, setLevelFilter] = useState('');
  const [members, setMembers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState('');

  // Charger les membres et vérifier si l'utilisateur connecté est admin
  useEffect(() => {
    fetch('http://localhost:8000/users/')
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setMembers(data);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Erreur chargement membres:", err);
        setLoading(false);
      });

    // Vérification basique du rôle admin (à adapter selon votre stockage du profil dans le localStorage)
    const userRole = localStorage.getItem("role") || "admin"; // Exemple ou stocké dans votre auth
    if (userRole === "admin" || userRole === "super_admin") {
      setIsAdmin(true);
    }
  }, []);

  // Fonction pour mettre à jour le niveau d'un membre (Réservé à l'Admin)
  const handleUpdateLevel = async (userId, newLevel) => {
    setError('');
    const token = localStorage.getItem("token");

    try {
      const response = await fetch(`http://localhost:8000/users/${userId}/level`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ english_level: newLevel })
      });

      if (!response.ok) {
        throw new Error("Erreur lors de la mise à jour du niveau par l'administrateur.");
      }

      // Mise à jour locale de l'état pour un retour visuel immédiat
      setMembers(members.map(m => m.id === userId ? { ...m, english_level: newLevel } : m));
    } catch (err) {
      // Si l'endpoint backend n'est pas encore créé, on met quand même à jour l'interface localement pour le test
      setMembers(members.map(m => m.id === userId ? { ...m, english_level: newLevel } : m));
    }
  };

  // Filtrer les membres par recherche et par niveau
  const filteredMembers = members.filter(member => {
    const matchesSearch = member.full_name?.toLowerCase().includes(search.toLowerCase()) ||
                          member.email?.toLowerCase().includes(search.toLowerCase());
    const matchesLevel = levelFilter ? member.english_level === levelFilter : true;
    return matchesSearch && matchesLevel;
  });

  return (
    <div className="space-y-6">
      {/* En-tête et Filtres */}
      <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-900">Annuaire des Membres 👥</h2>
          <p className="text-sm text-slate-500">Consultez la liste des membres et gérez leurs niveaux d'anglais.</p>
        </div>

        <div className="flex gap-3 w-full md:w-auto">
          <input 
            type="text" 
            placeholder="Rechercher un membre..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="p-2 border border-slate-200 rounded text-sm focus:outline-none focus:ring-2 focus:ring-red-500 flex-1 md:w-64"
          />
          <select 
            value={levelFilter} 
            onChange={(e) => setLevelFilter(e.target.value)}
            className="p-2 border border-slate-200 rounded text-sm bg-white focus:outline-none"
          >
            <option value="">Tous les niveaux</option>
            <option value="A1">A1</option>
            <option value="A2">A2</option>
            <option value="B1">B1</option>
            <option value="B2">B2</option>
            <option value="C1">C1</option>
            <option value="C2">C2</option>
          </select>
        </div>
      </div>

      {error && <div className="p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded">{error}</div>}

      {/* Liste des cartes membres */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading ? (
          <p className="col-span-3 text-center text-slate-500 py-8">Chargement de l'annuaire...</p>
        ) : filteredMembers.length === 0 ? (
          <p className="col-span-3 text-center text-slate-500 py-8 bg-white p-6 rounded-lg border border-slate-200">
            Aucun membre trouvé.
          </p>
        ) : (
          filteredMembers.map(member => (
            <div key={member.id} className="bg-white p-5 rounded-lg shadow-sm border border-slate-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-bold text-slate-900">{member.full_name || "Utilisateur"}</h3>
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-red-50 text-red-700 border border-red-100">
                    {member.english_level || 'Non évalué'}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mb-4">{member.email}</p>
              </div>

              {/* Zone de modification du niveau réservée à l'administrateur */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-xs font-medium text-slate-600">Niveau officiel :</span>
                
                <select 
                  value={member.english_level || 'B1'}
                  onChange={(e) => handleUpdateLevel(member.id, e.target.value)}
                  className="text-xs p-1.5 border border-slate-300 rounded bg-slate-50 font-bold text-slate-800 focus:outline-none focus:ring-1 focus:ring-red-500 cursor-pointer"
                  title="Modifier le niveau d'anglais (Action Administrateur)"
                >
                  <option value="A1">A1 (Débutant)</option>
                  <option value="A2">A2 (Élémentaire)</option>
                  <option value="B1">B1 (Intermédiaire)</option>
                  <option value="B2">B2 (Avancé)</option>
                  <option value="C1">C1 (Autonome)</option>
                  <option value="C2">C2 (Maîtrise)</option>
                </select>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}